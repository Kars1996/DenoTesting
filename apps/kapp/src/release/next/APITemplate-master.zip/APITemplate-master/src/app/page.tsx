"use client"
import { redirect } from 'next/navigation'

/*
Copyright © 2024 Kars (github.com/kars1996)

Not to be shared, replicated or used without prior consent.
Contact Kars for any enquieries
*/

export default function() {
    redirect('https://kars.bio/?ref=api')
    return null;
}